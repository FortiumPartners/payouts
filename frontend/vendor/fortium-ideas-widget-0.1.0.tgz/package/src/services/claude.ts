import type { CapturedContext } from '../context/types';

export interface InterviewQuestion {
  type: 'question';
  question: string;
  options?: { label: string; value: string }[];
  allowFreeText?: boolean;
}

export interface GeneratedIssue {
  type: 'issue';
  title: string;
  description: string;
  issueType: 'bug' | 'feature' | 'question' | 'other';
  labels: string[];
}

export interface AuthFailure {
  type: 'auth_failure';
}

export type InterviewResponse = InterviewQuestion | GeneratedIssue | AuthFailure;

/**
 * Conduct AI-powered intake interview via the Ideas API proxy.
 * The API handles Claude communication server-side to keep the API key secure.
 */
export async function conductInterview(
  apiUrl: string,
  getToken: () => Promise<string>,
  context: CapturedContext,
  conversationHistory: { role: 'user' | 'assistant'; content: string }[]
): Promise<InterviewResponse> {
  // Format context summary
  const contextSummary = formatContextSummary(context);

  // Build messages array with context as first user message
  const messages = [
    { role: 'user', content: contextSummary },
    ...conversationHistory,
  ];

  const makeRequest = async (token: string) =>
    fetch(`${apiUrl}/api/interview`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        messages,
        context: {
          app: { id: context.app.appId, name: context.app.appId },
          page: { title: context.page.title, path: context.page.path },
          user: context.user,
          browser: { name: context.browser.userAgent.split(' ')[0], version: '' },
          errors: context.state?.consoleErrors?.map((e) => ({ message: e })) || [],
        },
      }),
      signal: AbortSignal.timeout(60_000),
    });

  // First attempt
  let token = await getToken();
  let response = await makeRequest(token);

  // On 401, get a fresh token and retry once
  if (response.status === 401) {
    token = await getToken();
    response = await makeRequest(token);
  }

  if (!response.ok) {
    if (response.status === 401) {
      return { type: 'auth_failure' as const };
    }
    const error = await response.json().catch(() => ({ message: 'Unknown error' }));
    throw new Error(error.details || error.message || `Interview failed: ${response.status}`);
  }

  const result = await response.json();

  // Handle response from proxy
  if (result.type === 'complete' && result.issue) {
    // Proxy returned a complete issue
    return {
      type: 'issue',
      title: result.issue.title,
      description: result.issue.description,
      issueType: result.issue.type || 'other',
      labels: [],
    };
  }

  if (result.type === 'question' && result.message) {
    // Proxy returned a follow-up question
    // Try to parse it as our expected JSON format
    const text = result.message;
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      try {
        const parsed = JSON.parse(jsonMatch[0]);
        if (parsed.type === 'question' || parsed.type === 'issue') {
          return parsed as InterviewResponse;
        }
      } catch {
        // Not JSON, treat as plain question
      }
    }

    // Return as simple question
    return {
      type: 'question',
      question: text,
      allowFreeText: true,
    };
  }

  throw new Error('Unexpected response format from interview API');
}

function formatContextSummary(context: CapturedContext): string {
  const lines = [
    'User Context:',
    `- App: ${context.app.appId}`,
    `- Page: ${context.page.path} (${context.page.title})`,
    `- User: ${context.user?.email || 'Anonymous'}`,
    `- Device: ${context.browser.deviceType}, ${context.browser.viewport.width}x${context.browser.viewport.height}`,
    `- Time on page: ${context.page.timeOnPage}s`,
  ];

  if (context.state?.consoleErrors?.length) {
    lines.push(`- Recent errors: ${context.state.consoleErrors.slice(0, 3).join('; ')}`);
  }

  if (context.state?.customContext) {
    lines.push(`- App state: ${JSON.stringify(context.state.customContext)}`);
  }

  lines.push('');
  lines.push('Please help this user submit their feedback.');

  return lines.join('\n');
}

export function isAuthFailure(response: InterviewResponse): response is AuthFailure {
  return response.type === 'auth_failure';
}

export function isInterviewQuestion(response: InterviewResponse): response is InterviewQuestion {
  return response.type === 'question';
}

export function isGeneratedIssue(response: InterviewResponse): response is GeneratedIssue {
  return response.type === 'issue';
}
