import type { CapturedContext } from '../context/types';

export interface SubmissionPayload {
  appId: string;
  repo: string;
  title: string;
  description: string;
  type: string;
  context: CapturedContext;
}

export interface Submission {
  id: string;
  title: string;
  status: string;
  type: string;
  createdAt: string;
  githubIssueUrl?: string;
  archivedAt?: string;
}

export class AuthExpiredError extends Error {
  code = 'AUTH_EXPIRED' as const;
  constructor() {
    super('Your session has expired.');
    this.name = 'AuthExpiredError';
  }
}

export class IdeasApiClient {
  constructor(
    private baseUrl: string,
    private getToken: () => Promise<string>
  ) {}

  private async fetchWithAuth(
    url: string,
    options: RequestInit = {}
  ): Promise<Response> {
    const token = await this.getToken();
    const response = await fetch(url, {
      ...options,
      headers: { ...options.headers, Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(30_000),
    });

    if (response.status === 401) {
      // Token may have expired — get a fresh one and retry once
      const freshToken = await this.getToken();
      return fetch(url, {
        ...options,
        headers: { ...options.headers, Authorization: `Bearer ${freshToken}` },
        signal: AbortSignal.timeout(30_000),
      });
    }

    return response;
  }

  async createSubmission(payload: SubmissionPayload): Promise<Submission> {
    const response = await this.fetchWithAuth(
      `${this.baseUrl}/api/submissions`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }
    );
    if (!response.ok) {
      if (response.status === 401) {
        throw new AuthExpiredError();
      }
      const body = await response.json().catch(() => ({}));
      throw new Error(body.error || body.message || `Submission failed (${response.status})`);
    }
    return response.json();
  }

  async listSubmissions(appId?: string): Promise<Submission[]> {
    const url = appId
      ? `${this.baseUrl}/api/submissions?appId=${appId}`
      : `${this.baseUrl}/api/submissions`;
    const response = await this.fetchWithAuth(url);
    if (!response.ok) {
      if (response.status === 401) {
        throw new AuthExpiredError();
      }
      const body = await response.json().catch(() => ({}));
      throw new Error(body.error || body.message || `Request failed (${response.status})`);
    }
    const data = await response.json();
    return data.submissions;
  }
}
