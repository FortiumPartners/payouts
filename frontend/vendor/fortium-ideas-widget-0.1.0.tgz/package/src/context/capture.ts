import type { FortiumIdeasConfig } from '../index';
import type {
  UserContext,
  AppContext,
  PageContext,
  BrowserContext,
  AppState,
  CapturedContext,
} from './types';

let pageLoadTime: number = Date.now();
let consoleErrors: string[] = [];
let errorListenerInitialized = false;

/**
 * Detect device type based on viewport width and user agent
 */
export function detectDeviceType(): 'desktop' | 'tablet' | 'mobile' {
  const width = window.innerWidth;
  const userAgent = navigator.userAgent.toLowerCase();

  // Check user agent for mobile/tablet indicators
  const isMobileUA = /mobile|android|iphone|ipod/.test(userAgent);
  const isTabletUA = /tablet|ipad/.test(userAgent);

  if (isTabletUA || (width >= 768 && width < 1024 && !isMobileUA)) {
    return 'tablet';
  }

  if (isMobileUA || width < 768) {
    return 'mobile';
  }

  return 'desktop';
}

/**
 * Detect environment from URL or meta tags
 */
export function detectEnvironment(): 'production' | 'staging' | 'development' {
  const hostname = window.location.hostname;

  // Check for common development indicators
  if (
    hostname === 'localhost' ||
    hostname === '127.0.0.1' ||
    hostname.includes('.local') ||
    hostname.includes('dev.')
  ) {
    return 'development';
  }

  // Check for staging indicators
  if (
    hostname.includes('staging') ||
    hostname.includes('stage') ||
    hostname.includes('test') ||
    hostname.includes('preview')
  ) {
    return 'staging';
  }

  return 'production';
}

/**
 * Capture browser context information
 */
export function captureBrowserContext(): BrowserContext {
  return {
    userAgent: navigator.userAgent,
    language: navigator.language,
    viewport: {
      width: window.innerWidth,
      height: window.innerHeight,
    },
    platform: navigator.platform,
    deviceType: detectDeviceType(),
  };
}

/**
 * Capture current page context
 */
export function capturePageContext(): PageContext {
  return {
    url: window.location.href,
    path: window.location.pathname,
    title: document.title,
    referrer: document.referrer,
    timeOnPage: Math.round((Date.now() - pageLoadTime) / 1000),
  };
}

/**
 * Initialize context capture - sets up error listener if enabled
 */
export function initContextCapture(config: FortiumIdeasConfig): void {
  // Reset page load time
  pageLoadTime = Date.now();

  // Set up error listener if captureErrors is enabled
  if (config.captureErrors && !errorListenerInitialized) {
    window.addEventListener('error', (event: ErrorEvent) => {
      const errorMessage = `${event.message} at ${event.filename}:${event.lineno}:${event.colno}`;
      consoleErrors.push(errorMessage);

      // Keep only the last 10 errors to avoid memory issues
      if (consoleErrors.length > 10) {
        consoleErrors = consoleErrors.slice(-10);
      }
    });

    window.addEventListener('unhandledrejection', (event: PromiseRejectionEvent) => {
      const errorMessage = `Unhandled Promise Rejection: ${event.reason}`;
      consoleErrors.push(errorMessage);

      // Keep only the last 10 errors
      if (consoleErrors.length > 10) {
        consoleErrors = consoleErrors.slice(-10);
      }
    });

    errorListenerInitialized = true;
  }
}

/**
 * Capture all context information
 */
export function captureContext(
  config: FortiumIdeasConfig,
  user?: UserContext
): CapturedContext {
  // Build app context
  const appContext: AppContext = {
    appId: config.appId,
    repo: config.repo,
    environment: detectEnvironment(),
  };

  // Build app state
  const appState: AppState = {};

  // Get custom context from config callback if provided
  if (config.getContext) {
    try {
      appState.customContext = config.getContext();
    } catch (error) {
      console.warn('FortiumIdeas: Error getting custom context', error);
    }
  }

  // Include console errors if we captured any
  if (consoleErrors.length > 0) {
    appState.consoleErrors = [...consoleErrors];
  }

  const captured: CapturedContext = {
    app: appContext,
    page: capturePageContext(),
    browser: captureBrowserContext(),
    capturedAt: new Date().toISOString(),
  };

  // Only include user if provided
  if (user) {
    captured.user = user;
  }

  // Only include state if it has data
  if (Object.keys(appState).length > 0) {
    captured.state = appState;
  }

  return captured;
}

/**
 * Clear captured console errors (useful after submission)
 */
export function clearCapturedErrors(): void {
  consoleErrors = [];
}

/**
 * Get current console errors without clearing
 */
export function getCapturedErrors(): string[] {
  return [...consoleErrors];
}
