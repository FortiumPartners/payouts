export type {
  UserContext,
  AppContext,
  PageContext,
  BrowserContext,
  AppState,
  CapturedContext,
} from './types';

export {
  initContextCapture,
  captureContext,
  captureBrowserContext,
  capturePageContext,
  detectDeviceType,
  detectEnvironment,
  clearCapturedErrors,
  getCapturedErrors,
} from './capture';
