export interface UserContext {
  userId: string;
  email: string;
  name?: string;
  organization?: string;
  roles?: string[];
}

export interface AppContext {
  appId: string;
  appVersion?: string;
  environment?: 'production' | 'staging' | 'development';
  repo: string;
}

export interface PageContext {
  url: string;
  path: string;
  title: string;
  referrer: string;
  timeOnPage: number;
}

export interface BrowserContext {
  userAgent: string;
  language: string;
  viewport: { width: number; height: number };
  platform: string;
  deviceType: 'desktop' | 'tablet' | 'mobile';
}

export interface AppState {
  customContext?: Record<string, unknown>;
  recentActions?: string[];
  consoleErrors?: string[];
}

export interface CapturedContext {
  user?: UserContext;
  app: AppContext;
  page: PageContext;
  browser: BrowserContext;
  state?: AppState;
  capturedAt: string;
}
