import { h } from 'preact';
import type { Submission } from '../services/api';

interface SubmissionsListProps {
  submissions: Submission[];
  loading: boolean;
  error?: string | null;
  onRefresh: () => void;
  loginUrl?: string;
}

const STATUS_CONFIG = {
  submitted: { icon: '📤', color: '#6b7280', label: 'Submitted' },
  under_review: { icon: '👀', color: '#f59e0b', label: 'Under Review' },
  in_progress: { icon: '🔄', color: '#3b82f6', label: 'In Progress' },
  deployed: { icon: '✅', color: '#10b981', label: 'Deployed' },
  wont_fix: { icon: '❌', color: '#ef4444', label: "Won't Fix" },
  needs_info: { icon: '💬', color: '#8b5cf6', label: 'Needs Info' },
};

export function SubmissionsList({ submissions, loading, error, onRefresh, loginUrl }: SubmissionsListProps) {
  if (loading) {
    return (
      <div class="fortium-ideas-loading" role="status" aria-live="polite">
        <div class="fortium-ideas-loading-spinner" aria-hidden="true"></div>
        <span>Loading submissions...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div class="fortium-ideas-empty">
        <div class="fortium-ideas-empty-icon" aria-hidden="true">🔒</div>
        <p>{error}</p>
        {loginUrl && (
          <button
            type="button"
            class="fortium-ideas-refresh"
            onClick={() => {
              const popup = window.open(loginUrl, '_blank', 'popup,width=500,height=600');
              if (popup) {
                const interval = setInterval(() => {
                  if (popup.closed) {
                    clearInterval(interval);
                    setTimeout(onRefresh, 500);
                  }
                }, 500);
              }
            }}
          >
            Sign in
          </button>
        )}
      </div>
    );
  }

  if (submissions.length === 0) {
    return (
      <div class="fortium-ideas-empty">
        <div class="fortium-ideas-empty-icon" aria-hidden="true">📝</div>
        <p>No submissions yet</p>
        <p class="fortium-ideas-empty-muted">Your ideas and bug reports will appear here</p>
      </div>
    );
  }

  return (
    <div class="fortium-ideas-submissions-list">
      <div class="fortium-ideas-list-header">
        <span class="fortium-ideas-list-count">
          {submissions.length} submission{submissions.length !== 1 ? 's' : ''}
        </span>
        <button
          type="button"
          onClick={onRefresh}
          class="fortium-ideas-refresh"
          aria-label="Refresh submissions list"
        >
          <span aria-hidden="true">↻</span> Refresh
        </button>
      </div>
      <ul class="fortium-ideas-submissions-items" role="list">
        {submissions.map((submission) => {
          const status = STATUS_CONFIG[submission.status as keyof typeof STATUS_CONFIG] || STATUS_CONFIG.submitted;
          return (
            <li key={submission.id} class="fortium-ideas-submission-card">
              <div class="fortium-ideas-submission-header">
                <span
                  class="fortium-ideas-submission-type"
                  data-type={submission.type}
                  aria-label={`Type: ${submission.type}`}
                >
                  {submission.type}
                </span>
                <span class="fortium-ideas-submission-date">
                  <time dateTime={submission.createdAt}>
                    {formatDate(submission.createdAt)}
                  </time>
                </span>
              </div>
              <h4 class="fortium-ideas-submission-title">{submission.title}</h4>
              <div class="fortium-ideas-submission-footer">
                <span
                  class="fortium-ideas-submission-status"
                  style={{ color: status.color }}
                  aria-label={`Status: ${status.label}`}
                >
                  <span aria-hidden="true">{status.icon}</span> {status.label}
                </span>
                {submission.githubIssueUrl && (
                  <a
                    href={submission.githubIssueUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    class="fortium-ideas-github-link"
                  >
                    View on GitHub <span aria-hidden="true">→</span>
                  </a>
                )}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function formatDate(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));

  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 7) return `${days} days ago`;
  return date.toLocaleDateString();
}
