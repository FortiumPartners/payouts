import { h } from 'preact';
import { useState, useCallback, useEffect } from 'preact/hooks';
import type { CapturedContext } from '../context/types';
import {
  conductInterview,
  isAuthFailure,
  isInterviewQuestion,
  isGeneratedIssue,
  type InterviewResponse,
  type GeneratedIssue,
  type InterviewQuestion,
} from '../services/claude';
import { AuthExpiredError } from '../services/api';

type InterviewState =
  | 'initial'
  | 'interviewing'
  | 'preview'
  | 'submitting'
  | 'simple_form'
  | 'auth_required';

interface IntakeInterviewProps {
  context: CapturedContext;
  apiUrl: string;
  getToken: () => Promise<string>;
  onSubmit: (issue: GeneratedIssue) => Promise<void>;
  onCancel: () => void;
  loginUrl: string;
  authAvailable: boolean | null;
}

interface ConversationMessage {
  role: 'user' | 'assistant';
  content: string;
}

const INITIAL_OPTIONS = [
  { label: 'Report a bug', value: 'bug', icon: 'bug' },
  { label: 'Suggest a feature', value: 'feature', icon: 'lightbulb' },
  { label: 'Ask a question', value: 'question', icon: 'help' },
  { label: 'Something else', value: 'other', icon: 'more' },
] as const;

const ISSUE_TYPE_LABELS: Record<string, string> = {
  bug: 'Bug Report',
  feature: 'Feature Request',
  question: 'Question',
  other: 'Feedback',
};

export function IntakeInterview({
  context,
  apiUrl,
  getToken,
  onSubmit,
  onCancel,
  loginUrl,
  authAvailable,
}: IntakeInterviewProps) {
  const [state, setState] = useState<InterviewState>('initial');
  const [conversationHistory, setConversationHistory] = useState<ConversationMessage[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState<InterviewQuestion | null>(null);
  const [generatedIssue, setGeneratedIssue] = useState<GeneratedIssue | null>(null);
  const [freeTextInput, setFreeTextInput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [authExpired, setAuthExpired] = useState(false);

  // Simple form state
  const [simpleFormType, setSimpleFormType] = useState<string>('bug');
  const [simpleFormTitle, setSimpleFormTitle] = useState('');
  const [simpleFormDescription, setSimpleFormDescription] = useState('');

  // Layer 3: Start in simple_form if auth is already known to be unavailable
  useEffect(() => {
    if (authAvailable === false) {
      setAuthExpired(true);
      setState('simple_form');
    }
  }, [authAvailable]);

  const processResponse = useCallback((response: InterviewResponse) => {
    if (isAuthFailure(response)) {
      // Layer 1: Fall back to simple form on auth failure
      setAuthExpired(true);
      setState('simple_form');
    } else if (isInterviewQuestion(response)) {
      setCurrentQuestion(response);
      setState('interviewing');
    } else if (isGeneratedIssue(response)) {
      setGeneratedIssue(response);
      setState('preview');
    }
  }, []);

  const sendToClaudeWithHistory = useCallback(
    async (newHistory: ConversationMessage[]) => {
      setIsLoading(true);
      setError(null);

      try {
        const response = await conductInterview(apiUrl, getToken, context, newHistory);

        if (isAuthFailure(response)) {
          processResponse(response);
          return;
        }

        // Add assistant response to history
        const updatedHistory = [
          ...newHistory,
          { role: 'assistant' as const, content: JSON.stringify(response) },
        ];
        setConversationHistory(updatedHistory);

        processResponse(response);
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Failed to communicate with AI assistant');
      } finally {
        setIsLoading(false);
      }
    },
    [apiUrl, getToken, context, processResponse]
  );

  const handleInitialSelection = useCallback(
    async (value: string) => {
      const option = INITIAL_OPTIONS.find((o) => o.value === value);
      const userMessage = `I want to ${option?.label.toLowerCase() || value}`;

      // Pre-set simple form type in case we fall back
      setSimpleFormType(value);

      const newHistory: ConversationMessage[] = [
        { role: 'user', content: userMessage },
      ];
      setConversationHistory(newHistory);

      await sendToClaudeWithHistory(newHistory);
    },
    [sendToClaudeWithHistory]
  );

  const handleOptionSelection = useCallback(
    async (value: string) => {
      const newHistory: ConversationMessage[] = [
        ...conversationHistory,
        { role: 'user', content: value },
      ];
      setConversationHistory(newHistory);
      setFreeTextInput('');

      await sendToClaudeWithHistory(newHistory);
    },
    [conversationHistory, sendToClaudeWithHistory]
  );

  const handleFreeTextSubmit = useCallback(
    async (e: Event) => {
      e.preventDefault();
      if (!freeTextInput.trim()) return;

      await handleOptionSelection(freeTextInput.trim());
    },
    [freeTextInput, handleOptionSelection]
  );

  // Simple form submission — produces a GeneratedIssue and flows into handleSubmit
  const handleSimpleFormSubmit = useCallback(
    async (e: Event) => {
      e.preventDefault();
      if (!simpleFormTitle.trim() || !simpleFormDescription.trim()) return;

      const issue: GeneratedIssue = {
        type: 'issue',
        title: simpleFormTitle.trim(),
        description: simpleFormDescription.trim(),
        issueType: (simpleFormType as GeneratedIssue['issueType']) || 'other',
        labels: [],
      };
      setGeneratedIssue(issue);
      setState('preview');
    },
    [simpleFormTitle, simpleFormDescription, simpleFormType]
  );

  const handleSubmit = useCallback(async () => {
    if (!generatedIssue) return;

    setState('submitting');
    setError(null);
    try {
      const timeout = new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('Request timed out. Please try again.')), 30_000)
      );
      await Promise.race([onSubmit(generatedIssue), timeout]);
    } catch (e) {
      // Layer 2: Detect AuthExpiredError and offer re-auth
      if (e instanceof AuthExpiredError) {
        setState('auth_required');
        return;
      }
      setError(e instanceof Error ? e.message : 'Submission failed. Please try again.');
      setState('preview');
    }
  }, [generatedIssue, onSubmit]);

  // Layer 2: Open login popup and retry on close
  const handleReauth = useCallback(() => {
    const popup = window.open(loginUrl, '_blank', 'popup,width=500,height=600');
    if (!popup) {
      setError('Could not open login window. Please allow popups and try again.');
      return;
    }

    const interval = setInterval(() => {
      if (popup.closed) {
        clearInterval(interval);
        // Popup closed — retry submission
        setState('preview');
        // Small delay to let the new session cookie propagate
        setTimeout(() => {
          handleSubmit();
        }, 500);
      }
    }, 500);
  }, [loginUrl, handleSubmit]);

  const handleEditAndRestart = useCallback(() => {
    setState('initial');
    setConversationHistory([]);
    setCurrentQuestion(null);
    setGeneratedIssue(null);
    setFreeTextInput('');
    setError(null);
    setAuthExpired(false);
    setSimpleFormTitle('');
    setSimpleFormDescription('');
    setSimpleFormType('bug');
  }, []);

  // Render simple form (Layer 1 fallback)
  if (state === 'simple_form') {
    return (
      <div class="fortium-ideas-interview">
        <div class="fortium-ideas-interview-header">
          <h2 id="fortium-ideas-modal-title" class="fortium-ideas-interview-title">
            Submit Feedback
          </h2>
          {authExpired && (
            <p class="fortium-ideas-interview-auth-note">
              AI assistant unavailable — fill out the form below
            </p>
          )}
        </div>

        <form onSubmit={handleSimpleFormSubmit} class="fortium-ideas-simple-form">
          <div class="fortium-ideas-simple-form-field">
            <label class="fortium-ideas-simple-form-label" htmlFor="fi-type">Type</label>
            <select
              id="fi-type"
              class="fortium-ideas-simple-form-select"
              value={simpleFormType}
              onChange={(e) => setSimpleFormType((e.target as HTMLSelectElement).value)}
            >
              <option value="bug">Bug Report</option>
              <option value="feature">Feature Request</option>
              <option value="question">Question</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div class="fortium-ideas-simple-form-field">
            <label class="fortium-ideas-simple-form-label" htmlFor="fi-title">Title</label>
            <input
              id="fi-title"
              type="text"
              class="fortium-ideas-interview-input"
              placeholder="Brief summary of your feedback"
              value={simpleFormTitle}
              onInput={(e) => setSimpleFormTitle((e.target as HTMLInputElement).value)}
              required
            />
          </div>

          <div class="fortium-ideas-simple-form-field">
            <label class="fortium-ideas-simple-form-label" htmlFor="fi-desc">Description</label>
            <textarea
              id="fi-desc"
              class="fortium-ideas-simple-form-textarea"
              placeholder="Describe the issue or suggestion in detail..."
              value={simpleFormDescription}
              onInput={(e) => setSimpleFormDescription((e.target as HTMLTextAreaElement).value)}
              rows={4}
              required
            />
          </div>

          <div class="fortium-ideas-interview-actions fortium-ideas-interview-actions--preview">
            <button
              type="button"
              class="fortium-ideas-interview-cancel"
              onClick={onCancel}
            >
              Cancel
            </button>
            <button
              type="submit"
              class="fortium-ideas-interview-submit"
              disabled={!simpleFormTitle.trim() || !simpleFormDescription.trim()}
            >
              Continue
            </button>
          </div>
        </form>
      </div>
    );
  }

  // Render auth_required state (Layer 2)
  if (state === 'auth_required') {
    return (
      <div class="fortium-ideas-interview">
        <div class="fortium-ideas-interview-header">
          <h2 id="fortium-ideas-modal-title" class="fortium-ideas-interview-title">
            Session expired
          </h2>
          <p class="fortium-ideas-interview-subtitle">
            Your session has expired. Re-authenticate to submit your feedback.
          </p>
        </div>

        {error && <ErrorMessage message={error} />}

        <div class="fortium-ideas-interview-actions fortium-ideas-interview-actions--preview">
          <button
            type="button"
            class="fortium-ideas-interview-cancel"
            onClick={onCancel}
          >
            Cancel
          </button>
          <button
            type="button"
            class="fortium-ideas-interview-submit"
            onClick={handleReauth}
          >
            Re-authenticate
          </button>
        </div>
      </div>
    );
  }

  // Render initial state
  if (state === 'initial') {
    return (
      <div class="fortium-ideas-interview">
        <div class="fortium-ideas-interview-header">
          <h2 id="fortium-ideas-modal-title" class="fortium-ideas-interview-title">
            How can we help?
          </h2>
          <p class="fortium-ideas-interview-subtitle">
            Select an option to get started
          </p>
        </div>

        <div class="fortium-ideas-interview-options">
          {INITIAL_OPTIONS.map((option) => (
            <button
              key={option.value}
              type="button"
              class="fortium-ideas-interview-option"
              onClick={() => handleInitialSelection(option.value)}
              disabled={isLoading}
            >
              <span class={`fortium-ideas-interview-option-icon fortium-ideas-interview-option-icon--${option.icon}`}>
                {renderIcon(option.icon)}
              </span>
              <span class="fortium-ideas-interview-option-label">{option.label}</span>
            </button>
          ))}
        </div>

        {isLoading && <LoadingSpinner />}
        {error && <ErrorMessage message={error} />}
      </div>
    );
  }

  // Render interviewing state
  if (state === 'interviewing' && currentQuestion) {
    return (
      <div class="fortium-ideas-interview">
        <div class="fortium-ideas-interview-header">
          <h2 id="fortium-ideas-modal-title" class="fortium-ideas-interview-title">
            {currentQuestion.question}
          </h2>
        </div>

        {currentQuestion.options && currentQuestion.options.length > 0 && (
          <div class="fortium-ideas-interview-choices">
            {currentQuestion.options.map((option, index) => (
              <button
                key={index}
                type="button"
                class="fortium-ideas-interview-choice"
                onClick={() => handleOptionSelection(option.value)}
                disabled={isLoading}
              >
                {option.label}
              </button>
            ))}
          </div>
        )}

        {(currentQuestion.allowFreeText || !currentQuestion.options?.length) && (
          <form onSubmit={handleFreeTextSubmit} class="fortium-ideas-interview-freetext">
            <input
              type="text"
              class="fortium-ideas-interview-input"
              placeholder="Or type your own response..."
              value={freeTextInput}
              onInput={(e) => setFreeTextInput((e.target as HTMLInputElement).value)}
              disabled={isLoading}
              aria-label="Your response"
            />
            <button
              type="submit"
              class="fortium-ideas-interview-submit-input"
              disabled={isLoading || !freeTextInput.trim()}
              aria-label="Submit response"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14M12 5l7 7-7 7" />
              </svg>
            </button>
          </form>
        )}

        <div class="fortium-ideas-interview-actions">
          <button
            type="button"
            class="fortium-ideas-interview-back"
            onClick={handleEditAndRestart}
            disabled={isLoading}
          >
            Start over
          </button>
        </div>

        {isLoading && <LoadingSpinner />}
        {error && <ErrorMessage message={error} />}
      </div>
    );
  }

  // Render preview state
  if (state === 'preview' && generatedIssue) {
    return (
      <div class="fortium-ideas-interview">
        <div class="fortium-ideas-interview-header">
          <h2 id="fortium-ideas-modal-title" class="fortium-ideas-interview-title">
            Review your submission
          </h2>
          <p class="fortium-ideas-interview-subtitle">
            Here's what we'll submit based on your feedback
          </p>
        </div>

        <div class="fortium-ideas-interview-preview">
          <div class="fortium-ideas-interview-preview-type">
            <span class={`fortium-ideas-interview-preview-badge fortium-ideas-interview-preview-badge--${generatedIssue.issueType}`}>
              {ISSUE_TYPE_LABELS[generatedIssue.issueType] || 'Feedback'}
            </span>
          </div>

          <h3 class="fortium-ideas-interview-preview-title">
            {generatedIssue.title}
          </h3>

          <p class="fortium-ideas-interview-preview-description">
            {generatedIssue.description}
          </p>

          {generatedIssue.labels.length > 0 && (
            <div class="fortium-ideas-interview-preview-labels">
              {generatedIssue.labels.map((label, index) => (
                <span key={index} class="fortium-ideas-interview-preview-label">
                  {label}
                </span>
              ))}
            </div>
          )}
        </div>

        {error && <ErrorMessage message={error} />}

        <div class="fortium-ideas-interview-actions fortium-ideas-interview-actions--preview">
          <button
            type="button"
            class="fortium-ideas-interview-cancel"
            onClick={onCancel}
          >
            Cancel
          </button>
          <button
            type="button"
            class="fortium-ideas-interview-edit"
            onClick={handleEditAndRestart}
          >
            Start over
          </button>
          <button
            type="button"
            class="fortium-ideas-interview-submit"
            onClick={handleSubmit}
          >
            Submit
          </button>
        </div>
      </div>
    );
  }

  // Render submitting state
  if (state === 'submitting') {
    return (
      <div class="fortium-ideas-interview">
        <div class="fortium-ideas-interview-header">
          <h2 id="fortium-ideas-modal-title" class="fortium-ideas-interview-title">
            Submitting...
          </h2>
        </div>
        <LoadingSpinner />
      </div>
    );
  }

  return null;
}

function LoadingSpinner() {
  return (
    <div class="fortium-ideas-interview-loading" role="status" aria-label="Loading">
      <div class="fortium-ideas-interview-spinner" />
    </div>
  );
}

function ErrorMessage({ message }: { message: string }) {
  return (
    <div class="fortium-ideas-interview-error" role="alert">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="12" cy="12" r="10" />
        <path d="M12 8v4M12 16h.01" />
      </svg>
      <span>{message}</span>
    </div>
  );
}

function renderIcon(icon: string) {
  switch (icon) {
    case 'bug':
      return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M8 2l1.88 1.88M14.12 3.88L16 2M9 7.13v-1a3.003 3.003 0 116 0v1" />
          <path d="M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 014-4h4a4 4 0 014 4v3c0 3.3-2.7 6-6 6zM12 20v-9" />
          <path d="M6.53 9C4.6 8.8 3 7.1 3 5M6 13H2M3 21c0-2.1 1.7-3.9 3.8-4M20.97 5c0 2.1-1.6 3.8-3.5 4M22 13h-4M17.2 17c2.1.1 3.8 1.9 3.8 4" />
        </svg>
      );
    case 'lightbulb':
      return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
        </svg>
      );
    case 'help':
      return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="12" cy="12" r="10" />
          <path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3M12 17h.01" />
        </svg>
      );
    case 'more':
      return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="12" cy="12" r="1" />
          <circle cx="19" cy="12" r="1" />
          <circle cx="5" cy="12" r="1" />
        </svg>
      );
    default:
      return null;
  }
}
