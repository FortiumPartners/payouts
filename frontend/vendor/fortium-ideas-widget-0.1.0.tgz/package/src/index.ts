import { h, render } from 'preact';
import { App } from './App';
// Import all CSS
import './styles/button.css';
import './styles/modal.css';
import './styles/interview.css';
import './styles/submissions.css';

export interface FortiumIdeasConfig {
  appId: string;
  repo: string;
  apiUrl?: string;
  getContext?: () => Record<string, unknown>;
  captureErrors?: boolean;
  getToken?: () => Promise<string>;
  loginUrl?: string;
}

let container: HTMLElement | null = null;

export function init(config: FortiumIdeasConfig): void {
  // Create container if not exists
  if (!container) {
    container = document.createElement('div');
    container.id = 'fortium-ideas-root';
    document.body.appendChild(container);
  }

  render(h(App, { config }), container);
}

export function destroy(): void {
  if (container) {
    render(null, container);
    container.remove();
    container = null;
  }
}

export default { init, destroy };
