import { h } from 'preact';
import { useState, useCallback, useEffect } from 'preact/hooks';
import { FloatingButton, Modal, IntakeInterview, SubmissionsList } from './components';
import { captureContext, initContextCapture } from './context';
import { IdeasApiClient, AuthExpiredError } from './services/api';
import type { Submission } from './services/api';
import type { FortiumIdeasConfig } from './index';
import type { GeneratedIssue } from './services/claude';

/**
 * Decode a JWT and check if it's expired (with 30s buffer).
 * Returns true if token is missing, malformed, or expired.
 */
export function isTokenExpired(token: string): boolean {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    return !payload.exp || payload.exp * 1000 < Date.now() + 30_000;
  } catch {
    return true;
  }
}

interface AppProps {
  config: FortiumIdeasConfig;
}

export function App({ config }: AppProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [view, setView] = useState<'new' | 'list'>('new');
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [submissionsLoading, setSubmissionsLoading] = useState(false);
  const [submissionsError, setSubmissionsError] = useState<string | null>(null);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [authAvailable, setAuthAvailable] = useState<boolean | null>(null); // null = checking

  // Token getter function - always fetches fresh token
  const getToken = useCallback(() => {
    return config.getToken ? config.getToken() : Promise.resolve('');
  }, [config]);

  // Check token validity when widget opens
  useEffect(() => {
    if (!isOpen) return;
    let cancelled = false;
    (async () => {
      try {
        const token = await getToken();
        if (!cancelled) setAuthAvailable(!isTokenExpired(token));
      } catch {
        if (!cancelled) setAuthAvailable(false);
      }
    })();
    return () => { cancelled = true; };
  }, [isOpen, getToken]);

  // Initialize context capture
  initContextCapture(config);

  const loadSubmissions = useCallback(async () => {
    setSubmissionsLoading(true);
    setSubmissionsError(null);
    try {
      const client = new IdeasApiClient(
        config.apiUrl || 'https://ideas-api.fortium.app',
        config.getToken || (() => Promise.resolve(''))
      );
      const data = await client.listSubmissions(config.appId);
      setSubmissions(data);
    } catch (error) {
      if (error instanceof AuthExpiredError) {
        setAuthAvailable(false);
        setSubmissionsError('Session expired — sign back in to view your submissions.');
      } else {
        setSubmissionsError('Failed to load submissions.');
      }
    } finally {
      setSubmissionsLoading(false);
    }
  }, [config]);

  const handleOpen = useCallback(async () => {
    setIsOpen(true);
    setSubmitSuccess(false);
  }, []);

  const handleClose = useCallback(() => {
    setIsOpen(false);
    setSubmitSuccess(false);
  }, []);

  const handleSubmit = useCallback(async (issue: GeneratedIssue) => {
    const context = captureContext(config);
    const client = new IdeasApiClient(
      config.apiUrl || 'https://ideas-api.fortium.app',
      config.getToken || (() => Promise.resolve(''))
    );

    const VALID_TYPES = ['bug', 'feature', 'question', 'other'];
    const type = VALID_TYPES.includes(issue.issueType) ? issue.issueType : 'other';

    await client.createSubmission({
      appId: config.appId,
      repo: config.repo,
      title: issue.title,
      description: issue.description,
      type,
      context,
    });

    setSubmitSuccess(true);
    // Auto-close after success message
    setTimeout(() => {
      setIsOpen(false);
      setSubmitSuccess(false);
    }, 2000);
  }, [config]);

  return (
    <>
      <FloatingButton onClick={handleOpen} />
      <Modal isOpen={isOpen} onClose={handleClose}>
        {submitSuccess ? (
          <div class="fortium-ideas-success">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <polyline points="22,4 12,14.01 9,11.01" />
            </svg>
            <h2>Thank you!</h2>
            <p>Your feedback has been submitted successfully.</p>
          </div>
        ) : (
          <>
            {/* Tabs: New | My Submissions */}
            <div class="fortium-ideas-tabs">
              <button
                type="button"
                class={`fortium-ideas-tab ${view === 'new' ? 'fortium-ideas-tab--active' : ''}`}
                onClick={() => setView('new')}
              >
                New
              </button>
              <button
                type="button"
                class={`fortium-ideas-tab ${view === 'list' ? 'fortium-ideas-tab--active' : ''} ${authAvailable === false ? 'fortium-ideas-tab--disabled' : ''}`}
                onClick={() => {
                  if (authAvailable === false) return;
                  setView('list');
                  loadSubmissions();
                }}
                disabled={authAvailable === false}
                title={authAvailable === false ? 'Sign in to view submissions' : undefined}
              >
                My Submissions
              </button>
            </div>

            {view === 'new' ? (
              <IntakeInterview
                context={captureContext(config)}
                apiUrl={config.apiUrl || 'https://ideas.fortiumsoftware.com'}
                getToken={getToken}
                onSubmit={handleSubmit}
                onCancel={handleClose}
                loginUrl={config.loginUrl || '/auth/login'}
                authAvailable={authAvailable}
              />
            ) : (
              <SubmissionsList
                submissions={submissions}
                loading={submissionsLoading}
                error={submissionsError}
                onRefresh={loadSubmissions}
                loginUrl={config.loginUrl || '/auth/login'}
              />
            )}
          </>
        )}
      </Modal>
    </>
  );
}
