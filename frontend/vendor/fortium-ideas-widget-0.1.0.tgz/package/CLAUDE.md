# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

@fortium/ideas-widget - Embeddable feedback widget with AI-powered intake interview for Fortium applications.

## Tech Stack

- Preact (lightweight React alternative)
- TypeScript
- Vite (bundler)
- Anthropic Claude API (intake interview)

## Commands

```bash
npm run dev      # Start dev server with HMR
npm run build    # Build ES/UMD bundles to dist/
npm run preview  # Preview production build
```

## Architecture

- `src/index.ts` - Entry point, init() and destroy() functions
- `src/App.tsx` - Main widget app component
- `src/components/` - UI components (FloatingButton, Modal, IntakeInterview, SubmissionsList)
- `src/context/` - Browser context capture system
- `src/services/` - API client and Claude integration
- `src/styles/` - CSS for each component

## Usage

```typescript
import { init } from '@fortium/ideas-widget';

init({
  appId: 'partner-connect',
  repo: 'fortium/partner-connect',
  apiUrl: 'https://ideas-api.fortium.app',
  claudeApiKey: 'sk-ant-...',
  getToken: () => getIdentityToken(),
  getContext: () => ({ currentView: router.currentRoute }),
  captureErrors: true,
});
```

## Build Output

- `dist/fortium-ideas.es.js` - ES module
- `dist/fortium-ideas.umd.js` - UMD bundle (for script tags)
- `dist/style.css` - Combined styles (must be imported separately)
